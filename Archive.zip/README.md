
# Google Unread Counter

See how many unread emails you have in Inbox/Gmail tab icon.

## Usage

After installing the chrome extension open Google Inbox/Gmail in Chrome.
The extension will try to find out how many unread emails you have in your inbox from the html, if it can't it will poll the server.

## TODO

1. Add user settings
  * Timers
  * Characters 
  * Favicon settings, shape, animation, colours etc...

## License

MIT
